import { Page } from "puppeteer";

export async function typeText(
  page: Page,
  selector: string,
  text: string
) {
  await page.waitForSelector(selector, { timeout: 10000 });

  await page.click(selector, { clickCount: 3 });
  await page.keyboard.press("Backspace");

  await page.type(selector, text);
}

export async function clickElement(
  page: Page,
  selector: string,
  options?: {
    waitForNavigation?: boolean;
    waitForSelectorAfter?: string;
  }
) {
  await page.waitForSelector(selector, { timeout: 10000 });

  if (options?.waitForNavigation) {
    await Promise.all([
      page.click(selector),
      page.waitForNavigation({ waitUntil: "networkidle2" }),
    ]);
  } else {
    await page.click(selector);
  }

  if (options?.waitForSelectorAfter) {
    await page.waitForSelector(options.waitForSelectorAfter, { timeout: 10000 });
  }
}

export async function selectDropdown(page: Page, selector: string, value: string) {
  await page.waitForSelector(selector, { timeout: 10000 });
  await page.select(selector, value);
}