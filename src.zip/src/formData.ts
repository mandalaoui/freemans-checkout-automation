import { FormField } from "./types";

export const formFields: FormField[] = [
  {
    fieldName: "firstname",
    selector: 'input[name="firstname"]',
    property: "value",
    value: "Steve",
  },
  {
    fieldName: "lastname",
    selector: 'input[name="lastname"]',
    property: "value",
    value: "Rosenblum",
  },
  {
    fieldName: "email",
    selector: 'input[name="email"]',
    property: "value",
    value: "steve@example.com",
  },
  {
    fieldName: "phone",
    selector: 'input[name="phone"]',
    property: "value",
    value: "07123456789",
  },
];

export const formData = {
  title: "Mr",
  firstName: "Steve",
  lastName: "Rosenblum",

  day: "10",
  month: "05",
  year: "1995",

  // British number in international (GB) format
  phone: "07123456789",

  house: "12",

  // UK postcode
  postcode: "EC1A 1BB",

  email: "test@example.com",
  password: "Test1234!",
};