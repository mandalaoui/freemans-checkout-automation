export const selectors = {
  cookieAcceptButton: 'button',
  searchInput: "#searchBox",
  searchButton: ".mhSearchButton",
  bagButton: "a.xfoBagLink",
  addToBagButton: "button.primary.bagButton",
  sizeButton: 'span.productOptionItem',
  colorButton: 'span.productOptionItem.productSwatchItem',
  checkoutButton: "#proceedbutton2",
  guestCheckoutButton: "#registerLink",
};

export const formSelectors = {
  title: "#Title",
  firstName: "#FirstName",
  lastName: "#LastName",

  day: "#dob_day",
  month: "#dob_month",
  year: "#dob_year",

  phone: "#DayTimeTelephone",

  house: "#houseId",
  postcode: "#postCode",

  email: "#Email",
  confirmEmail: "#ConfirmEmail",

  password: "#Password",
  confirmPassword: "#confirmPassword",
};