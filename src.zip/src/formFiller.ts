import { Page } from "puppeteer";
import { initDb } from "./db";
import { typeText, selectDropdown } from "./actions";

export async function fillForm(page: Page) {
  const db = await initDb();

  const fields = await db.all("SELECT * FROM form_fields");

  for (const field of fields) {
    const { selector, property, value } = field;

    if (property === "value") {
      if (selector === "#Title" || selector.includes("dob_")) {
        await selectDropdown(page, selector, value);
      } else {
        await typeText(page, selector, value);
      }
    }
  }

  console.log("Form filled from DB");
}