import { initDb } from "./db";

async function seed() {
  const db = await initDb();

  await db.exec("DELETE FROM form_fields");

  await db.run(`
    INSERT INTO form_fields (field_name, selector, property, value) VALUES
    ('title', '#Title', 'value', 'Mr'),
    ('firstName', '#FirstName', 'value', 'Steve'),
    ('lastName', '#LastName', 'value', 'Rosenblum'),

    ('day', '#dob_day', 'value', '10'),
    ('month', '#dob_month', 'value', '05'),
    ('year', '#dob_year', 'value', '1995'),

    ('phone', '#DayTimeTelephone', 'value', '07123456789'),

    ('house', '#houseId', 'value', '12'),
    ('postcode', '#postCode', 'value', 'SW1A 1AA'),

    ('email', '#Email', 'value', 'test@example.com'),
    ('confirmEmail', '#ConfirmEmail', 'value', 'test@example.com'),

    ('password', '#Password', 'value', 'Test1234!'),
    ('confirmPassword', '#confirmPassword', 'value', 'Test1234!')
  `);

  console.log("DB seeded");
}

seed();