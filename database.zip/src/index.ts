import { launchBrowser } from "./browser";
import { goToHomepage, goToBag } from "./navigation";
import { fillDeliveryForm } from "./formFiller";

async function run() {
  try {
    const { page } = await launchBrowser();

    await goToHomepage(page);
    await goToBag(page);
    await page.goto("PRODUCT_URL");
    await fillDeliveryForm(page);
  } catch (e) {
    console.error("An error occurred during the script execution:", e);
  }
}

run();