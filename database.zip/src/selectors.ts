export const selectors = {
    searchInput: "#searchBox",
    searchButton: ".mhSearchButton",
    bagButton: "a.xfoBagLink",
  };