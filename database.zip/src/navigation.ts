import { Page } from "puppeteer";
import { selectors } from "./selectors";

export async function goToHomepage(page: Page) {
  await page.goto("https://www.freemans.com/", {
    waitUntil: "networkidle2",
  });

  console.log("Homepage loaded");
}

export async function goToBag(page: Page) {
  await page.waitForSelector(selectors.bagButton);
  await page.click(selectors.bagButton);

  console.log("Navigated to bag");
}